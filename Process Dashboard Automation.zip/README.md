# Inbound Process Dashboard Automation (Professional)

## Overview
Automates inbound shipment tracking and provides an Excel-based dashboard for NOC and Logistics teams. This repository includes both a **Python automation** pipeline and an **Excel/VBA** option for teams preferring no-code automation inside Microsoft Excel.

## What is included
- `data/inbound_sample_data.csv` – sample inbound export
- `dashboard/inbound_dashboard_template.xlsx` – Excel template (Raw Data, PivotData, Dashboard)
- `dashboard/automation_script.vba` – VBA macro to refresh connections and update timestamp
- `code/data_processing.py` – Python script to compute KPIs and update the dashboard
- `code/requirements.txt` – Python dependencies
- `docs/project_report.pdf` – short project report
- `README.md` – this file

## Quick Start (Python)
1. Create a virtual environment and install requirements:

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\\Scripts\\activate
pip install -r code/requirements.txt
```

2. Run the processing script:

```bash
python code/data_processing.py --input data/inbound_sample_data.csv --template dashboard/inbound_dashboard_template.xlsx --output dashboard/inbound_dashboard_updated.xlsx
```

3. Open `dashboard/inbound_dashboard_updated.xlsx` to view updated KPIs and data.

## Quick Start (Excel + VBA)
1. Open `dashboard/inbound_dashboard_template.xlsx` in Excel.
2. Import `dashboard/automation_script.vba` into the VBA editor (Alt+F11) as a module.
3. Run `RefreshInboundDashboard` macro or attach it to a button on the Dashboard sheet.

## Suggested Enhancements
- Integrate Power BI for interactive visuals and scheduled refresh.
- Add automated email summaries using SMTP/Power Automate.
- Connect directly to ServiceNow or database endpoints for live data ingestion.

## Author
Nithyasri R. B. — Transportation & NOC Specialist
Contact: nithyabala1403@gmail.com | LinkedIn: https://www.linkedin.com/in/nithyasrirb
