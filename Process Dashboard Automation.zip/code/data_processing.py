"""
data_processing.py
Processes inbound CSV exports and generates KPI summaries and an updated Excel dashboard.
Requirements: pandas, openpyxl
Usage: python data_processing.py --input data/inbound_sample_data.csv --output dashboard/inbound_dashboard_updated.xlsx
"""

import argparse
import pandas as pd
from openpyxl import load_workbook

def load_data(path):
    df = pd.read_csv(path, parse_dates=["Date"]) 
    return df

def compute_kpis(df):
    total = len(df)
    on_time = df[df["Status"]=="Completed"].shape[0]
    delayed = df[df["Status"]=="Delayed"].shape[0]
    cancelled = df[df["Status"]=="Cancelled"].shape[0]
    avg_delay = df["Delay_Minutes"].dropna().astype(float).mean() if df["Delay_Minutes"].notna().any() else 0
    return {
        "Total_Appointments": int(total),
        "On_Time": int(on_time),
        "Delayed": int(delayed),
        "Cancelled": int(cancelled),
        "Average_Delay_Minutes": float(avg_delay)
    }

def update_excel_dashboard(template_path, output_path, kpis, raw_df):
    wb = load_workbook(template_path)
    if "PivotData" in wb.sheetnames:
        ws = wb["PivotData"]
        for row in ws["A2:B100"]:
            for cell in row:
                cell.value = None
        ws["A1"] = "KPI"
        ws["B1"] = "Value"
        ws["A2"] = "Total Appointments"
        ws["B2"] = kpis["Total_Appointments"]
        ws["A3"] = "On-Time Deliveries"
        ws["B3"] = kpis["On_Time"]
        ws["A4"] = "Delayed Appointments"
        ws["B4"] = kpis["Delayed"]
        ws["A5"] = "Cancelled"
        ws["B5"] = kpis["Cancelled"]
        ws["A6"] = "Average Delay Minutes"
        ws["B6"] = kpis["Average_Delay_Minutes"]
    if "Raw Data" in wb.sheetnames:
        wsraw = wb["Raw Data"]
        max_row = wsraw.max_row
        if max_row > 1:
            wsraw.delete_rows(2, max_row-1)
        for row in raw_df.itertuples(index=False, name=None):
            wsraw.append(list(row))
    if "Dashboard" in wb.sheetnames:
        ws = wb["Dashboard"]
        try:
            ws["B2"] = "Last Refreshed: " + pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")
        except:
            pass
    wb.save(output_path)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Input CSV file path")
    parser.add_argument("--template", required=False, default="dashboard/inbound_dashboard_template.xlsx", help="Excel template path")
    parser.add_argument("--output", required=False, default="dashboard/inbound_dashboard_updated.xlsx", help="Output Excel path")
    args = parser.parse_args()
    df = load_data(args.input)
    kpis = compute_kpis(df)
    update_excel_dashboard(args.template, args.output, kpis, df)
    print("Dashboard updated:", args.output)

if __name__ == "__main__":
    main()
